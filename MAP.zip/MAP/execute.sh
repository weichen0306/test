#!/bin/bash

###################
###goble varible
###################
DIR=/sbin
DIR_ovs=/usr/bin/
flag=1

###################
###function
###################

function clearroutegateway () {
    gateway=$( route -n | grep "10.10.1" )
    while read line; do
        echo "$line"
        ip route del 0/0
    done <<< "$gateway"
    route -n
}

function execute () {
    echo "$@"
    eval "$@"
}

function cleartable () {
    execute ${DIR_ovs}ovs-ofctl del-flows ovsbr1 table=30
}

function addtable30 () {
         while read line;
         do
             olsrdgateway=$( echo "/route" | nc localhost 2006 | grep 0.0.0.0 | awk '{print $2}' )
             arp_ip=$( echo "$line" | awk '{print $1}' )

             if [ $olsrdgateway = $arp_ip ]
             then
                 arp_mac=$( echo "$line" | awk '{print $2}' )
                 echo "$line"
                 echo "$arp_mac"
                 echo "$arp_ip" > /tmp/temp
                 ${DIR_ovs}ovs-ofctl add-flow ovsbr1 priority=100,table=30,ip,nw_src=10.10.1.4,actions=mod_dl_dst=${arp_mac},output:1
                 echo "==="                  
             fi

         done <<< "$( cat /proc/net/arp | grep 10.10.1 | awk '{print $1 FS $4}' )"
}

function createtemp () {
    touch /tmp/temp
    truncate -s 0 /tmp/temp
}


###################
### main
###################

while [ 1 ]
do
    is_controller=$( ovs-vsctl show | grep "is_connected:" | awk '{print $2}' )

    if [ "$is_controller" = true ]
    then 
        flag=1
        table100=$( /usr/bin/ovs-ofctl dump-flows ovsbr1 | grep "table=100" | awk '{print $7}' | cut -d '=' -f 3 )
        echo "$table100"
        echo ""
        olsrdgateway=$( route -n | grep "10.10.1" | awk '{print $2}')

        if [ $table100 = $olsrdgateway ]
        then
             echo "abcde"
#            sleep 1
        else
             if [ -n "$table100" ]
             then    
                 clearroutegateway
                 ${DIR}/route add default gw ${table100}
             fi    
        fi

        echo ""
        route -n
        truncate -s 0 /tmp/temp
        flag=1
        echo "####################################"
     else
         if [ "$flag" = 1 ]
         then
             ip route del 0/0
             cleartable
             createtemp
             flag=0
         fi
         
         if [ -s /tmp/temp ]
         then
             olsrdgateway=$( echo "/route" | nc localhost 2006 | grep 0.0.0.0 | awk '{print $2}' )
             
             if [ -z $olsrdgateway ]
             then
                 ip route del 0/0
             else
                 temp=$( cat /tmp/temp )
            
                 if [ $temp != $olsrdgateway ]
                 then
                      cleartable
                      addtable30
                      echo "a"
                 fi
                 echo "b"
             fi
             
         else
             olsrdgateway=$( echo "/route" | nc localhost 2006 | grep 0.0.0.0 | awk '{print $2}' )
             
             if [ -z $olsrdgateway ]
             then   
                 ip route del 0/0
             else
                 cleartable
                 addtable30
                 echo "c"
             fi
         fi
     fi

sleep 1
done

exit 0
