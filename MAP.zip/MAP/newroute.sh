#!/bin/bash

bridge_mac=$( ifconfig | grep "ovsbr1" | awk '{print $5}' )
bridge_ip=$( ip -4 addr show dev ovsbr1 | grep -m 1 "inet " | awk '{print $2}' | cut -d "/" -f 1 )
eth0_mac=$( ifconfig | grep "eth0" | awk '{print $5}' )

DIR_flows=/usr/bin

############################
submittable1="resubmit(,1)"
submittable2="resubmit(,2)"
submittable5="resubmit(,5)"
submittable10="resubmit(,10)"
submittable11="resubmit(,11)"
submittable20="resubmit(,20)"
submittable30="resubmit(,30)"
submittable105="resubmit(,105)"


######################################
### mac
######################################

ovsbr1_mac_4="60:e3:27:08:6f:cb"
ovsbr1_mac_1="c0:4a:00:24:41:ed"
ovsbr1_mac_99="60:e3:27:08:11:b4"
ovsbr1_mac_20="60:e3:27:10:26:89"
ovsbr1_mac_1="60:e3:27:08:12:4b"

rpi3_mac_9="60:e3:27:1c:76:24"
wificlient_mac="74:e5:0b:13:d1:38"

noteclient_mac="14:da:e9:4b:cf:f2"

mikeclient_mac="78:24:af:9c:44:36"

tplinklan_mac="f8:1a:67:42:c3:0a"

labwifi_mac="74:e5:0b:13:d1:38"

######################################
### IP
######################################

eth0_IP="192.168.6.1"


printandexec () {
    echo "$@"
    eval "$@"
}

clearrule () {
     printandexec ${DIR_flows}/ovs-ofctl del-flows ovsbr1 "table=1"
     printandexec ${DIR_flows}/ovs-ofctl del-flows ovsbr1 "table=2"
     printandexec ${DIR_flows}/ovs-ofctl del-flows ovsbr1 "table=5"
     printandexec ${DIR_flows}/ovs-ofctl del-flows ovsbr1 "table=10"
     printandexec ${DIR_flows}/ovs-ofctl del-flows ovsbr1 "table=11"
     printandexec ${DIR_flows}/ovs-ofctl del-flows ovsbr1 "table=20"
     printandexec ${DIR_flows}/ovs-ofctl del-flows ovsbr1 "table=30"
     printandexec ${DIR_flows}/ovs-ofctl del-flows ovsbr1 "table=105"
}

printrule () {
     printandexec ${DIR_flows}/ovs-ofctl dump-flows ovsbr1
}

main(){
     if [ "$1" = "clear" ]
     then
         clearrule
     elif [ "$1" = "print" ]
     then
         printrule
     else
##         clearrule
###     table 0 - access control

        printandexec ${DIR_flows}/ovs-ofctl add-flow ovsbr1 priority=10,table=0,udp,in_port=LOCAL,tp_dst=698,actions=output:1
        printandexec ${DIR_flows}/ovs-ofctl add-flow ovsbr1 priority=10,table=0,udp,in_port=1,tp_src=698,actions=output:LOCAL
        
        printandexec ${DIR_flows}/ovs-ofctl add-flow ovsbr1 priority=61000,table=0,udp,tp_src=67,actions=normal
        printandexec ${DIR_flows}/ovs-ofctl add-flow ovsbr1 priority=61000,table=0,udp,tp_src=68,actions=normal


        ${DIR_flows}/ovs-ofctl add-flow ovsbr1 priority=0,table=0,actions=${submittable1}

###    table 1 - Classifier

        ${DIR_flows}/ovs-ofctl add-flow ovsbr1 "table=1,priority=1000,dl_type=0x0806,actions=${submittable105}"

        ${DIR_flows}/ovs-ofctl add-flow ovsbr1 "table=1,priority=200,ip,nw_src=10.10.2.110,nw_dst=10.10.1.4,actions=local"
        ${DIR_flows}/ovs-ofctl add-flow ovsbr1 "table=1,priority=200,ip,nw_src=10.10.1.4,nw_dst=10.10.2.110,actions=output:2"

        ${DIR_flows}/ovs-ofctl add-flow ovsbr1 "table=1,priority=100,dl_dst=${bridge_mac},actions=${submittable5}"
        ${DIR_flows}/ovs-ofctl add-flow ovsbr1 "table=1,priority=100,dl_dst=${eth0_mac},actions=${submittable5}"

###    table 5 - NAT

#      SNAT
       ${DIR_flows}/ovs-ofctl add-flow ovsbr1 priority=100,table=5,ip,nw_src=10.10.2.110,actions=mod_nw_src=10.10.1.4,${submittable10}

#      DNAT
       ${DIR_flows}/ovs-ofctl add-flow ovsbr1 priority=100,table=5,ip,nw_dst=10.10.1.4,actions=mod_nw_dst=10.10.2.110,${submittable11}


###    table 10 - netmask(192.168.5.0/24) routing

       ${DIR_flows}/ovs-ofctl add-flow ovsbr1 priority=100,table=10,ip,nw_src=10.10.1.0/24,actions=mod_dl_src=${bridge_mac},${submittable30}

###    table 11 - netmask(192.168.2.0/24) routing

       ${DIR_flows}/ovs-ofctl add-flow ovsbr1 priority=100,table=11,ip,nw_dst=10.10.2.0/24,actions=mod_dl_src=${eth0_mac},${submittable20}

###    table 20 - Forwarding inside

       ${DIR_flows}/ovs-ofctl add-flow ovsbr1 priority=100,table=20,ip,nw_dst=10.10.2.110,actions=mod_dl_dst=${noteclient_mac},output:2

###    table 30 - Forwarding outside

#       ${DIR_flows}/ovs-ofctl add-flow ovsbr1 priority=100,table=30,ip,nw_src=10.10.1.4,actions=mod_dl_dst=${ovsbr1_mac_20},output:1

       ${DIR_flows}/ovs-ofctl add-flow ovsbr1 priority=100,table=30,ip,nw_src=10.10.1.4,actions=mod_dl_dst=${ovsbr1_mac_1},output:1

         
###    table 105 arp responder

        ${DIR_flows}/ovs-ofctl add-flow ovsbr1 "priority=10,table=105,dl_type=0x0806,nw_dst=10.10.2.1,actions=move:NXM_OF_ETH_SRC[]->NXM_OF_ETH_DST[],mod_dl_src:${eth0_mac},load:0x2->NXM_OF_ARP_OP[],move:NXM_NX_ARP_SHA[]->NXM_NX_ARP_THA[],move:NXM_OF_ARP_SPA[]->NXM_OF_ARP_TPA[],load:0xb827ebd6989d->NXM_NX_ARP_SHA[],load:0x0a0a0201->NXM_OF_ARP_SPA[],in_port"

         ${DIR_flows}/ovs-ofctl add-flow ovsbr1 "priority=10,table=105,dl_type=0x0806,nw_dst=10.10.2.110,actions=move:NXM_OF_ETH_SRC[]->NXM_OF_ETH_DST[],mod_dl_src:${noteclient_mac},load:0x2->NXM_OF_ARP_OP[],move:NXM_NX_ARP_SHA[]->NXM_NX_ARP_THA[],move:NXM_OF_ARP_SPA[]->NXM_OF_ARP_TPA[],load:0x14dae94bcff2->NXM_NX_ARP_SHA[],load:0x0a0a026e->NXM_OF_ARP_SPA[],in_port"
 
        ${DIR_flows}/ovs-ofctl add-flow ovsbr1 "priority=10,table=105,dl_type=0x0806,nw_dst=10.10.1.4,actions=move:NXM_OF_ETH_SRC[]->NXM_OF_ETH_DST[],mod_dl_src:${bridge_mac},load:0x2->NXM_OF_ARP_OP[],move:NXM_NX_ARP_SHA[]->NXM_NX_ARP_THA[],move:NXM_OF_ARP_SPA[]->NXM_OF_ARP_TPA[],load:0x60e327086fcb->NXM_NX_ARP_SHA[],load:0x0a0a0104->NXM_OF_ARP_SPA[],in_port"


       printandexec ${DIR_flows}/ovs-ofctl add-flow ovsbr1 priority=0,table=105,arp,nw_src=10.10.1.0/24,actions=normal


        sleep 3
        printrule

     fi
}

main $1
#echo "$eth0_mac"

exit 0
